The official source code for 3.0 version of [Django for APIs](https://djangoforapis.com). Available as an [ebook](https://gum.co/EzsI) or [paperback](https://www.amazon.com/dp/1735467227/?tag=wsvincent-20).

![Cover](cover30.jpg)
