The official source code for [https://djangoforbeginners.com/](https://djangoforbeginners.com/). Available as an [ebook](https://gum.co/aFiMm) or in [Paperback](https://www.amazon.com/dp/1983172669/?tag=wsvincent-20).

[![Cover](bookcover.jpg)](https://djangoforbeginners.com/)

If you have the 3.0 version, please refer to [this repo for the source code](https://github.com/wsvincent/djangoforbeginners_30).
